import Link from "next/link";
import { hasPermission, type Permission } from "@/core/auth/permissions";

interface NavItem {
  href: string;
  label: string;
  permission: Permission;
  soon?: boolean;
}

const NAV_ITEMS: NavItem[] = [
  { href: "/hr", label: "RRHH", permission: "hr:employees:read" },
  { href: "/hr/schedules", label: "Horarios", permission: "hr:schedules:read" },
  { href: "/menu", label: "Menú del día", permission: "menu:read" },
  {
    href: "/suppliers",
    label: "Proveedores",
    permission: "hr:employees:read", // placeholder, futuro
    soon: true,
  },
];

interface SidebarProps {
  role: string;
  currentPath: string;
}

export function Sidebar({ role, currentPath }: SidebarProps) {
  const visibleItems = NAV_ITEMS.filter(
    (item) => item.soon || hasPermission(role, item.permission)
  );

  return (
    <aside className="w-56 shrink-0 border-r border-border bg-card flex flex-col h-screen sticky top-0">
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-5 border-b border-border">
        <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center shrink-0">
          <span className="text-white text-sm font-bold">CB</span>
        </div>
        <span className="text-sm font-semibold leading-tight">
          Cruz Blanca
          <br />
          <span className="text-muted-foreground font-normal">Gestión</span>
        </span>
      </div>

      {/* Navegación */}
      <nav className="flex-1 px-2 py-4 space-y-0.5 overflow-y-auto">
        <Link
          href="/"
          className={`flex items-center gap-2 rounded-md px-3 py-2 text-sm transition-colors ${
            currentPath === "/"
              ? "bg-primary/10 text-primary font-medium"
              : "text-foreground hover:bg-muted"
          }`}
        >
          Inicio
        </Link>

        {visibleItems.map((item) =>
          item.soon ? (
            <div
              key={item.href}
              className="flex items-center justify-between rounded-md px-3 py-2 text-sm text-muted-foreground cursor-not-allowed"
            >
              <span>{item.label}</span>
              <span className="text-xs bg-muted rounded px-1.5 py-0.5">
                Próximo
              </span>
            </div>
          ) : (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-2 rounded-md px-3 py-2 text-sm transition-colors ${
                currentPath.startsWith(item.href)
                  ? "bg-primary/10 text-primary font-medium"
                  : "text-foreground hover:bg-muted"
              }`}
            >
              {item.label}
            </Link>
          )
        )}
      </nav>

      {/* Footer con rol */}
      <div className="px-4 py-3 border-t border-border">
        <p className="text-xs text-muted-foreground">
          Rol:{" "}
          <span className="font-medium text-foreground">{role}</span>
        </p>
      </div>
    </aside>
  );
}
