/**
 * Seed de desarrollo — solo datos ficticios
 * Idempotente: puede ejecutarse múltiples veces sin duplicar datos
 */
import { PrismaClient } from "@prisma/client";
import { hash } from "@node-rs/argon2";

const prisma = new PrismaClient();

// ── ROLES ────────────────────────────────────────────────────
const ROLES = [
  { name: "ADMIN", description: "Acceso total al sistema" },
  {
    name: "RRHH",
    description: "Gestión completa de recursos humanos",
  },
  {
    name: "ENCARGADO",
    description:
      "Gestión de menús y consulta de horarios de empleados",
  },
  {
    name: "COCINA",
    description: "Consulta del menú del día vigente",
  },
];

// ── PERMISOS ─────────────────────────────────────────────────
const ALL_PERMISSIONS = [
  // Administración
  "users:manage",
  "system:settings",
  "system:audit",
  // RRHH — empleados
  "hr:employees:read",
  "hr:employees:write",
  // RRHH — contratos
  "hr:contracts:read",
  "hr:contracts:write",
  // RRHH — horarios (ENCARGADO puede leer de todos)
  "hr:schedules:read",
  "hr:schedules:write",
  // RRHH — registros de jornada
  "hr:records:read",
  "hr:records:write",
  // RRHH — documentos laborales
  "hr:documents:read",
  "hr:documents:write",
  // Menú
  "menu:read",
  "menu:write",
  "menu:pdf:generate",
];

// ── PERMISOS POR ROL ─────────────────────────────────────────
const ROLE_PERMISSIONS: Record<string, string[]> = {
  ADMIN: ALL_PERMISSIONS,
  RRHH: [
    "hr:employees:read",
    "hr:employees:write",
    "hr:contracts:read",
    "hr:contracts:write",
    "hr:schedules:read",
    "hr:schedules:write",
    "hr:records:read",
    "hr:records:write",
    "hr:documents:read",
    "hr:documents:write",
    "menu:read",
    "menu:write",
    "menu:pdf:generate",
  ],
  ENCARGADO: [
    "hr:schedules:read", // ver horarios de todos (sin datos sensibles)
    "menu:read",
    "menu:write",
    "menu:pdf:generate",
  ],
  COCINA: [
    "menu:read", // solo menú del día vigente
  ],
};

// ── CONFIGURACIÓN INICIAL DE EMPRESA ─────────────────────────
const DEFAULT_SETTINGS = [
  { key: "company.name", value: "Cruz Blanca (nombre provisional)" },
  { key: "company.cif", value: "A00000000 (provisional)" },
  { key: "company.ccc", value: "000-0000-00-0000000000 (provisional)" },
  { key: "company.address", value: "Dirección del restaurante (provisional)" },
  {
    key: "timerecord.legal_text",
    value:
      "El trabajador y la empresa firman el presente registro de jornada en conformidad con lo dispuesto en el artículo 34.9 del Estatuto de los Trabajadores.",
  },
];

async function main() {
  console.log("🌱 Iniciando seed de desarrollo...");

  // 1. Crear roles
  const roleMap: Record<string, { id: string }> = {};
  for (const role of ROLES) {
    const r = await prisma.role.upsert({
      where: { name: role.name },
      update: { description: role.description },
      create: role,
    });
    roleMap[role.name] = r;
    console.log(`  ✓ Rol: ${role.name}`);
  }

  // 2. Crear permisos
  const permMap: Record<string, { id: string }> = {};
  for (const action of ALL_PERMISSIONS) {
    const p = await prisma.permission.upsert({
      where: { action },
      update: {},
      create: { action },
    });
    permMap[action] = p;
  }
  console.log(`  ✓ ${ALL_PERMISSIONS.length} permisos creados`);

  // 3. Asignar permisos a roles
  for (const [roleName, perms] of Object.entries(ROLE_PERMISSIONS)) {
    const roleId = roleMap[roleName]?.id;
    if (!roleId) continue;
    for (const action of perms) {
      const permissionId = permMap[action]?.id;
      if (!permissionId) continue;
      await prisma.rolePermission.upsert({
        where: {
          roleId_permissionId: { roleId, permissionId },
        },
        update: {},
        create: { roleId, permissionId },
      });
    }
  }
  console.log("  ✓ Permisos asignados a roles");

  // 4. Usuario administrador ficticio
  const adminRole = roleMap["ADMIN"];
  if (!adminRole) throw new Error("Rol ADMIN no encontrado");

  const provisionalPassword = "Provisional1234!";
  const passwordHash = await hash(provisionalPassword, {
    memoryCost: 65536, // 64 MB
    timeCost: 3,
    parallelism: 1,
  });

  const adminUser = await prisma.user.upsert({
    where: { email: "admin@cruzblanca.local" },
    update: {},
    create: {
      email: "admin@cruzblanca.local",
      passwordHash,
      name: "Administrador",
      roleId: adminRole.id,
      isActive: true,
      mustChangePwd: true, // obligar a cambiar en primer login
    },
  });
  console.log(`  ✓ Usuario admin: ${adminUser.email}`);
  console.log(
    `    ⚠  Contraseña provisional: ${provisionalPassword} (cambiar en primer login)`
  );

  // 5. Usuario RRHH ficticio
  const rrhRole = roleMap["RRHH"];
  if (rrhRole) {
    await prisma.user.upsert({
      where: { email: "rrhh@cruzblanca.local" },
      update: {},
      create: {
        email: "rrhh@cruzblanca.local",
        passwordHash: await hash("Provisional1234!", {
          memoryCost: 65536,
          timeCost: 3,
          parallelism: 1,
        }),
        name: "Gestor RRHH (ficticio)",
        roleId: rrhRole.id,
        isActive: true,
        mustChangePwd: true,
      },
    });
    console.log("  ✓ Usuario rrhh@cruzblanca.local (ficticio)");
  }

  // 6. Usuario ENCARGADO ficticio
  const encRole = roleMap["ENCARGADO"];
  if (encRole) {
    await prisma.user.upsert({
      where: { email: "encargado@cruzblanca.local" },
      update: {},
      create: {
        email: "encargado@cruzblanca.local",
        passwordHash: await hash("Provisional1234!", {
          memoryCost: 65536,
          timeCost: 3,
          parallelism: 1,
        }),
        name: "Encargado (ficticio)",
        roleId: encRole.id,
        isActive: true,
        mustChangePwd: true,
      },
    });
    console.log("  ✓ Usuario encargado@cruzblanca.local (ficticio)");
  }

  // 7. Usuario COCINA ficticio
  const cocinaRole = roleMap["COCINA"];
  if (cocinaRole) {
    await prisma.user.upsert({
      where: { email: "cocina@cruzblanca.local" },
      update: {},
      create: {
        email: "cocina@cruzblanca.local",
        passwordHash: await hash("Provisional1234!", {
          memoryCost: 65536,
          timeCost: 3,
          parallelism: 1,
        }),
        name: "Cocina (ficticio)",
        roleId: cocinaRole.id,
        isActive: true,
        mustChangePwd: true,
      },
    });
    console.log("  ✓ Usuario cocina@cruzblanca.local (ficticio)");
  }

  // 8. Configuración inicial
  for (const setting of DEFAULT_SETTINGS) {
    await prisma.appSetting.upsert({
      where: { key: setting.key },
      update: {},
      create: { key: setting.key, value: setting.value },
    });
  }
  console.log("  ✓ Configuración inicial de empresa");

  console.log("\n✅ Seed completado.");
  console.log("\nUsuarios de desarrollo disponibles:");
  console.log(
    "  admin@cruzblanca.local     / Provisional1234!  (ADMIN)"
  );
  console.log(
    "  rrhh@cruzblanca.local      / Provisional1234!  (RRHH)"
  );
  console.log(
    "  encargado@cruzblanca.local / Provisional1234!  (ENCARGADO)"
  );
  console.log(
    "  cocina@cruzblanca.local    / Provisional1234!  (COCINA)"
  );
  console.log(
    "\n  ⚠  Todos los usuarios deben cambiar la contraseña en el primer login."
  );
}

main()
  .catch((e) => {
    console.error("❌ Error en seed:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
