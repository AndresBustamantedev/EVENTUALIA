"use client";

/**
 * DishAutocomplete — campo de búsqueda de platos con resultados en tiempo real.
 * Llama a searchDishes (server action) con debounce de 250 ms.
 */

import { useState, useRef, useTransition, useEffect, useCallback } from "react";
import { searchDishes } from "@/modules/menu/actions/dishes";
import type { DishRow } from "@/modules/menu/actions/dishes";

export interface DishAutocompleteProps {
  category: string;
  onSelect: (dish: DishRow) => void;
  placeholder?: string;
}

export function DishAutocomplete({
  category,
  onSelect,
  placeholder = "Buscar plato…",
}: DishAutocompleteProps) {
  const [query, setQuery]       = useState("");
  const [results, setResults]   = useState<DishRow[]>([]);
  const [open, setOpen]         = useState(false);
  const [isPending, startTransition] = useTransition();
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);

  const search = useCallback(
    (q: string) => {
      if (!q.trim()) { setResults([]); setOpen(false); return; }
      startTransition(async () => {
        const res = await searchDishes(q, category || undefined);
        setResults(res);
        setOpen(res.length > 0);
      });
    },
    [category]
  );

  useEffect(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => search(query), 250);
    return () => { if (timerRef.current) clearTimeout(timerRef.current); };
  }, [query, search]);

  // Cerrar al hacer click fuera
  useEffect(() => {
    function handler(e: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  function handleSelect(dish: DishRow) {
    onSelect(dish);
    setQuery("");
    setResults([]);
    setOpen(false);
  }

  return (
    <div ref={wrapperRef} className="relative">
      <input
        type="text"
        value={query}
        onChange={e => setQuery(e.target.value)}
        placeholder={isPending ? "Buscando…" : placeholder}
        className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm
                   placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        autoComplete="off"
      />
      {open && results.length > 0 && (
        <ul className="absolute z-50 mt-1 w-full rounded-md border border-input bg-popover
                        shadow-md max-h-60 overflow-y-auto">
          {results.map(dish => (
            <li key={dish.id}>
              <button
                type="button"
                onClick={() => handleSelect(dish)}
                className="w-full px-3 py-2 text-left text-sm hover:bg-accent hover:text-accent-foreground
                           flex items-center justify-between"
              >
                <span>{dish.name}</span>
                {dish.allergens && (
                  <span className="text-xs text-muted-foreground ml-2 truncate max-w-[120px]">
                    {dish.allergens}
                  </span>
                )}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
