"use client";

/**
 * MenuEditor — gestión interactiva de los platos de un menú.
 * Permite añadir platos por categoría mediante autocompletado y eliminarlos.
 */

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { DishAutocomplete } from "./DishAutocomplete";
import { addDishToMenuAction, removeDishFromMenuAction } from "@/modules/menu/actions/dailyMenus";
import type { MenuDishRow } from "@/modules/menu/actions/dailyMenus";
import type { DishRow } from "@/modules/menu/actions/dishes";
import { DISH_CATEGORY_LABELS } from "@/modules/menu/lib/menuUtils";

interface Props {
  menuId: string;
  dishes: MenuDishRow[];
  isActive: boolean;
  canWrite: boolean;
}

function DishList({
  menuId,
  dishes,
  category,
  label,
  isActive,
  canWrite,
}: {
  menuId: string;
  dishes: MenuDishRow[];
  category: string;
  label: string;
  isActive: boolean;
  canWrite: boolean;
}) {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();
  const filtered = dishes.filter(d => d.category === category);

  function handleAdd(dish: DishRow) {
    startTransition(async () => {
      const res = await addDishToMenuAction(menuId, dish.id, category);
      if (res.error) alert(res.error);
      else router.refresh();
    });
  }

  function handleRemove(menuDishId: string) {
    startTransition(async () => {
      const res = await removeDishFromMenuAction(menuId, menuDishId);
      if (res.error) alert(res.error);
      else router.refresh();
    });
  }

  return (
    <div>
      <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-2">
        {label}
      </h3>
      {filtered.length === 0 ? (
        <p className="text-sm text-muted-foreground italic mb-3">Sin platos en esta categoría.</p>
      ) : (
        <ul className="space-y-1 mb-3">
          {filtered.map(d => (
            <li
              key={d.id}
              className="flex items-center justify-between rounded-md border border-input px-3 py-2 text-sm"
            >
              <span className="flex items-center gap-2">
                <span className="text-muted-foreground">❖</span>
                {d.dishName}
              </span>
              {canWrite && !isActive && (
                <button
                  type="button"
                  disabled={isPending}
                  onClick={() => handleRemove(d.id)}
                  className="text-xs text-destructive hover:underline ml-4"
                  title="Quitar del menú"
                >
                  Quitar
                </button>
              )}
            </li>
          ))}
        </ul>
      )}

      {canWrite && !isActive && (
        <DishAutocomplete
          category={category}
          onSelect={handleAdd}
          placeholder={`Añadir ${label.toLowerCase()}…`}
        />
      )}
    </div>
  );
}

export function MenuEditor({ menuId, dishes, isActive, canWrite }: Props) {
  const categories: Array<{ key: string; label: string }> = [
    { key: "FIRST",  label: DISH_CATEGORY_LABELS["FIRST"]  ?? "Primeros" },
    { key: "SECOND", label: DISH_CATEGORY_LABELS["SECOND"] ?? "Segundos" },
    { key: "OTHER",  label: DISH_CATEGORY_LABELS["OTHER"]  ?? "Otros" },
  ];

  return (
    <div className="space-y-6">
      {categories.map(({ key, label }) => (
        <DishList
          key={key}
          menuId={menuId}
          dishes={dishes}
          category={key}
          label={label}
          isActive={isActive}
          canWrite={canWrite}
        />
      ))}
    </div>
  );
}
