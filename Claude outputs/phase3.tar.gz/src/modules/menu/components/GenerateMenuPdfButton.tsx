"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { generateMenuPdfAction } from "@/modules/menu/actions/generatePdf";

interface Props {
  menuId: string;
  currentPdfId?: string | null;
}

export function GenerateMenuPdfButton({ menuId, currentPdfId }: Props) {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();

  function handleGenerate() {
    startTransition(async () => {
      const result = await generateMenuPdfAction(menuId);
      if (result.error) {
        alert(result.error);
      } else {
        router.refresh();
      }
    });
  }

  return (
    <div className="flex items-center gap-2">
      <button
        onClick={handleGenerate}
        disabled={isPending}
        className="rounded-md border border-input px-3 py-1.5 text-sm hover:bg-muted transition-colors"
      >
        {isPending ? "Generando PDF…" : currentPdfId ? "Regenerar PDF" : "Generar PDF"}
      </button>
      {currentPdfId && !isPending && (
        <a
          href={`/api/files/menu-pdf/${currentPdfId}`}
          target="_blank"
          rel="noopener noreferrer"
          className="rounded-md border border-input px-3 py-1.5 text-sm hover:bg-muted transition-colors"
        >
          Ver PDF
        </a>
      )}
    </div>
  );
}
