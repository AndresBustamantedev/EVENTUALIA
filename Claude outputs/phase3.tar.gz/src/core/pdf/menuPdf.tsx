/**
 * Generador de PDF — Menú del día Cruz Blanca
 *
 * Usa @react-pdf/renderer (Node.js, sin browser).
 * Se ejecuta solo en el servidor.
 *
 * 3 páginas A4 landscape:
 *   1. Primeros platos  — branding + watermark
 *   2. Segundos platos  — branding + watermark + texto legal
 *   3. Cocina           — solo platos, sin decoración
 */
import React from "react";
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  renderToBuffer,
} from "@react-pdf/renderer";

// ── Tipos ─────────────────────────────────────────────────────

export interface MenuPdfDish {
  name: string;
  allergens?: string | null;
}

export interface MenuPdfData {
  menuDate: string;       // "Lunes 2/09/2026"
  menuDateLong: string;   // "lunes, 2 de septiembre de 2026"
  priceFormatted: string; // "14,50 €"
  firstCourses: MenuPdfDish[];
  secondCourses: MenuPdfDish[];
  otherDishes: MenuPdfDish[];
}

// ── Estilos ───────────────────────────────────────────────────

const BLACK  = "#000000";
const WHITE  = "#FFFFFF";
const GRAY50 = "#F5F5F5";
const GRAY80 = "#7A7A7A";

const styles = StyleSheet.create({
  page: {
    flexDirection: "column",
    backgroundColor: WHITE,
    fontFamily: "Helvetica",
    paddingTop: 28,
    paddingBottom: 40,
    paddingHorizontal: 40,
    position: "relative",
  },

  // ── Cabecera ─────────────────────────────────────────────
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 10,
  },
  brandBlock: {
    flexDirection: "column",
  },
  brandName: {
    fontSize: 15,
    fontFamily: "Helvetica-Bold",
    letterSpacing: 1.5,
    color: BLACK,
  },
  brandSub: {
    fontSize: 8,
    color: GRAY80,
    marginTop: 2,
    letterSpacing: 0.5,
  },
  titleBlock: {
    flexDirection: "column",
    alignItems: "flex-end",
  },
  menuTitle: {
    fontSize: 22,
    fontFamily: "Helvetica-Bold",
    color: BLACK,
    letterSpacing: 3,
  },
  menuDate: {
    fontSize: 9,
    color: GRAY80,
    marginTop: 3,
    letterSpacing: 0.5,
  },

  // ── Separador ─────────────────────────────────────────────
  divider: {
    height: 1.5,
    backgroundColor: BLACK,
    marginBottom: 6,
  },
  subDivider: {
    height: 0.5,
    backgroundColor: GRAY80,
    marginBottom: 8,
  },

  // ── Subtítulo de precio / calidad ─────────────────────────
  priceRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 18,
  },
  priceRowText: {
    fontSize: 9,
    color: GRAY80,
    letterSpacing: 0.3,
  },
  priceHighlight: {
    fontSize: 9,
    fontFamily: "Helvetica-Bold",
    color: BLACK,
  },

  // ── Sección de platos ──────────────────────────────────────
  sectionTitle: {
    fontSize: 16,
    fontFamily: "Helvetica-Bold",
    color: BLACK,
    marginBottom: 12,
    letterSpacing: 0.5,
  },
  dishRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: 9,
    paddingLeft: 6,
  },
  dishBullet: {
    fontSize: 11,
    color: BLACK,
    marginRight: 8,
    marginTop: 1,
  },
  dishName: {
    fontSize: 13,
    color: BLACK,
    flex: 1,
    lineHeight: 1.35,
  },
  dishAllergens: {
    fontSize: 7.5,
    color: GRAY80,
    marginTop: 2,
    paddingLeft: 19,
  },

  // ── Nota derecha (segundos) ────────────────────────────────
  noteRight: {
    fontSize: 8,
    color: GRAY80,
    textAlign: "right",
    marginBottom: 14,
    marginTop: -8,
    fontFamily: "Helvetica-Oblique",
    letterSpacing: 0.2,
  },

  // ── Texto legal ───────────────────────────────────────────
  legalBlock: {
    marginTop: "auto",
    paddingTop: 10,
    borderTopWidth: 0.5,
    borderTopColor: GRAY80,
  },
  legalText: {
    fontSize: 7,
    color: GRAY80,
    lineHeight: 1.5,
    textAlign: "justify",
  },

  // ── Pie negro ─────────────────────────────────────────────
  footer: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    height: 18,
    backgroundColor: BLACK,
  },

  // ── Watermark ─────────────────────────────────────────────
  watermark: {
    position: "absolute",
    top: "30%",
    left: "50%",
    fontSize: 120,
    color: GRAY50,
    opacity: 0.18,
    transform: "translate(-50%, -50%) rotate(-15deg)",
    zIndex: -1,
  },

  // ── Hoja de cocina ────────────────────────────────────────
  kitchenPage: {
    flexDirection: "column",
    backgroundColor: WHITE,
    fontFamily: "Helvetica",
    paddingTop: 36,
    paddingBottom: 40,
    paddingHorizontal: 50,
  },
  kitchenHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },
  kitchenTitle: {
    fontSize: 14,
    fontFamily: "Helvetica-Bold",
    color: BLACK,
    letterSpacing: 2,
  },
  kitchenDate: {
    fontSize: 10,
    color: GRAY80,
  },
  kitchenDivider: {
    height: 2,
    backgroundColor: BLACK,
    marginBottom: 18,
  },
  kitchenSectionTitle: {
    fontSize: 13,
    fontFamily: "Helvetica-Bold",
    color: BLACK,
    marginBottom: 10,
    marginTop: 4,
    letterSpacing: 0.5,
  },
  kitchenDishRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: 11,
    paddingLeft: 4,
  },
  kitchenBullet: {
    fontSize: 13,
    color: BLACK,
    marginRight: 10,
    marginTop: 1,
  },
  kitchenDishName: {
    fontSize: 15,
    color: BLACK,
    flex: 1,
    lineHeight: 1.3,
  },
  kitchenSectionGap: {
    height: 20,
  },
});

// ── Componentes internos ───────────────────────────────────────

const DIAMOND = "❖";

function DishEntry({ dish }: { dish: MenuPdfDish }) {
  return (
    <View>
      <View style={styles.dishRow}>
        <Text style={styles.dishBullet}>{DIAMOND}</Text>
        <Text style={styles.dishName}>{dish.name}</Text>
      </View>
      {dish.allergens ? (
        <Text style={styles.dishAllergens}>Alérgenos: {dish.allergens}</Text>
      ) : null}
    </View>
  );
}

function KitchenDishEntry({ dish }: { dish: MenuPdfDish }) {
  return (
    <View style={styles.kitchenDishRow}>
      <Text style={styles.kitchenBullet}>{DIAMOND}</Text>
      <Text style={styles.kitchenDishName}>{dish.name}</Text>
    </View>
  );
}

// ── Páginas ────────────────────────────────────────────────────

function PagePrimeros({ data }: { data: MenuPdfData }) {
  return (
    <Page size="A4" orientation="landscape" style={styles.page}>
      {/* Cabecera */}
      <View style={styles.header}>
        <View style={styles.brandBlock}>
          <Text style={styles.brandName}>CRUZ BLANCA</Text>
          <Text style={styles.brandSub}>Cervecería · Restaurante</Text>
        </View>
        <View style={styles.titleBlock}>
          <Text style={styles.menuTitle}>MENÚ DEL DÍA</Text>
          <Text style={styles.menuDate}>{data.menuDateLong}</Text>
        </View>
      </View>

      <View style={styles.divider} />

      {/* Precio */}
      <View style={styles.priceRow}>
        <Text style={styles.priceRowText}>Calidad al mejor precio</Text>
        <Text style={styles.priceRowText}>
          Precio por menú{" "}
          <Text style={styles.priceHighlight}>{data.priceFormatted}</Text>
        </Text>
      </View>

      {/* Platos */}
      <Text style={styles.sectionTitle}>Primeros Platos</Text>
      {data.firstCourses.map((d, i) => (
        <DishEntry key={i} dish={d} />
      ))}
      {data.otherDishes.length > 0 && (
        <>
          <View style={styles.subDivider} />
          {data.otherDishes.map((d, i) => (
            <DishEntry key={i} dish={d} />
          ))}
        </>
      )}

      {/* Pie */}
      <View style={styles.footer} />
    </Page>
  );
}

function PageSegundos({ data }: { data: MenuPdfData }) {
  return (
    <Page size="A4" orientation="landscape" style={styles.page}>
      {/* Cabecera */}
      <View style={styles.header}>
        <Text style={styles.sectionTitle}>Segundos Platos</Text>
        <Text style={styles.noteRight}>
          Todas nuestras carnes y pescados están preparados en horno de leña
        </Text>
      </View>

      <View style={styles.divider} />

      {/* Platos */}
      <View style={{ marginTop: 10 }}>
        {data.secondCourses.map((d, i) => (
          <DishEntry key={i} dish={d} />
        ))}
      </View>

      {/* Texto legal */}
      <View style={styles.legalBlock}>
        <Text style={styles.legalText}>
          El precio del menú incluye: primer plato, segundo plato, pan, bebida (agua, vino de la
          casa o refresco) y postre o café. Los platos pueden pedirse por separado a precio de
          carta. Sujeto a disponibilidad hasta fin de existencias. Precios con IVA incluido.
          Establecimiento inscrito en el Registro de Empresas Turísticas de la Comunidad de
          Madrid. Si tiene alguna alergia o intolerancia alimentaria, consulte con nuestro
          personal antes de realizar su pedido. Información sobre alérgenos disponible en el
          local. Imagen meramente orientativa.
        </Text>
      </View>

      {/* Pie */}
      <View style={styles.footer} />
    </Page>
  );
}

function PageCocina({ data }: { data: MenuPdfData }) {
  return (
    <Page size="A4" orientation="landscape" style={styles.kitchenPage}>
      {/* Cabecera cocina */}
      <View style={styles.kitchenHeader}>
        <Text style={styles.kitchenTitle}>COCINA — MENÚ DEL DÍA</Text>
        <Text style={styles.kitchenDate}>{data.menuDate}</Text>
      </View>

      <View style={styles.kitchenDivider} />

      {/* Primeros */}
      {data.firstCourses.length > 0 && (
        <>
          <Text style={styles.kitchenSectionTitle}>Primeros</Text>
          {data.firstCourses.map((d, i) => (
            <KitchenDishEntry key={i} dish={d} />
          ))}
        </>
      )}

      {data.otherDishes.length > 0 && (
        <>
          {data.firstCourses.length > 0 && <View style={styles.kitchenSectionGap} />}
          <Text style={styles.kitchenSectionTitle}>Otros</Text>
          {data.otherDishes.map((d, i) => (
            <KitchenDishEntry key={i} dish={d} />
          ))}
        </>
      )}

      {/* Segundos */}
      {data.secondCourses.length > 0 && (
        <>
          <View style={styles.kitchenSectionGap} />
          <Text style={styles.kitchenSectionTitle}>Segundos</Text>
          {data.secondCourses.map((d, i) => (
            <KitchenDishEntry key={i} dish={d} />
          ))}
        </>
      )}
    </Page>
  );
}

// ── Documento completo ─────────────────────────────────────────

function MenuDocument({ data }: { data: MenuPdfData }) {
  return (
    <Document
      title={`Menú del día — ${data.menuDate}`}
      author="Cruz Blanca Gestión"
      subject="Menú del día"
    >
      <PagePrimeros data={data} />
      <PageSegundos data={data} />
      <PageCocina data={data} />
    </Document>
  );
}

// ── Exportación ────────────────────────────────────────────────

export async function generateMenuPdfBuffer(data: MenuPdfData): Promise<Buffer> {
  const buf = await renderToBuffer(<MenuDocument data={data} />);
  return Buffer.from(buf);
}
